#v1 after full code
from blockchain_module import ProofOfShareBlockchain, generate_shares, add_blocks_from_excel, validate_ledger

# Initialize Node
secret = 123
total_shares = 5
threshold = 3
shares = generate_shares(secret, total_shares, threshold)

blockchain = ProofOfShareBlockchain("node1_ledger.txt", shares)

# Node specific share and other nodes' shares
node_id = 1
node_share = shares[0]
other_shares = [shares[1], shares[2]]  # Example shares from other nodes

# Add blocks from Excel
add_blocks_from_excel(blockchain, node_share, other_shares, node_id)

# Validate the ledger
validate_ledger("node1_ledger.txt")

# Display the ledger
blockchain.display_ledger()

