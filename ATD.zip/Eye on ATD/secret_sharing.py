import random
from sympy import mod_inverse

# Function to split secret using Shamir's Secret Sharing
def generate_shares(secret, total_shares, threshold):
    coefficients = [secret] + [random.randint(0, 255) for _ in range(threshold - 1)]
    shares = []
    for i in range(1, total_shares + 1):
        x = i
        y = sum([coefficients[j] * (x ** j) for j in range(threshold)]) % 257
        shares.append((x, y))
    return shares

# Function to reconstruct the secret using Lagrange interpolation
def reconstruct_secret(shares):
    secret = 0
    for i, (xi, yi) in enumerate(shares):
        numerator, denominator = 1, 1
        for j, (xj, _) in enumerate(shares):
            if i != j:
                numerator = (numerator * (-xj)) % 257
                denominator = (denominator * (xi - xj)) % 257
        secret = (secret + yi * numerator * mod_inverse(denominator, 257)) % 257
    return secret

# Example secret and shares generation
secret = 123  # The secret to split
total_shares = 5
threshold = 3

shares = generate_shares(secret, total_shares, threshold)
print("Generated Shares: ", shares)

# Example of reconstructing the secret using any 3 shares
subset_of_shares = random.sample(shares, 3)
reconstructed_secret = reconstruct_secret(subset_of_shares)
print("Reconstructed Secret: ", reconstructed_secret)
