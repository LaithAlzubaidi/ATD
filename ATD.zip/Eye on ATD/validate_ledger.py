import hashlib

def validate_ledger(ledger_file):
    with open(ledger_file, 'r') as ledger:
        previous_hash = "0"
        for line in ledger.readlines():
            index, prev_hash, timestamp, data, hash = line.strip().split(',')
            calculated_hash = hashlib.sha256(f"{index}{prev_hash}{timestamp}{data}".encode()).hexdigest()
            if calculated_hash != hash or prev_hash != previous_hash:
                print(f"Invalid Block at index {index}")
                return False
            previous_hash = hash
    print("Blockchain Ledger is Valid")
    return True

# Validate the blockchain
validate_ledger("blockchain_ledger.txt")
