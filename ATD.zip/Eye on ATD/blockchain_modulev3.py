import random
import hashlib
import time
import os
import pandas as pd
from sympy import mod_inverse
from tkinter import Tk
from tkinter.filedialog import askopenfilename
from phe import paillier  # Paillier homomorphic encryption
import csv


# Paillier Homomorphic Encryption (Key Generation and Encryption/Decryption)
def generate_paillier_keys():
    public_key, private_key = paillier.generate_paillier_keypair()
    return public_key, private_key


# Secret Sharing Functions (as is)
def generate_shares(secret, total_shares, threshold):
    coefficients = [secret] + [random.randint(0, 255) for _ in range(threshold - 1)]
    shares = []
    for i in range(1, total_shares + 1):
        x = i
        y = sum([coefficients[j] * (x ** j) for j in range(threshold)]) % 257
        shares.append((x, y))
    return shares


def reconstruct_secret(shares):
    secret = 0
    for i, (xi, yi) in enumerate(shares):
        numerator, denominator = 1, 1
        for j, (xj, _) in enumerate(shares):
            if i != j:
                numerator = (numerator * (-xj)) % 257
                denominator = (denominator * (xi - xj)) % 257
        secret = (secret + yi * numerator * mod_inverse(denominator, 257)) % 257
    return secret


# Blockchain Classes
class Block:
    def __init__(self, index, previous_hash, timestamp, data, hash, node_id):
        self.index = index
        self.previous_hash = previous_hash
        self.timestamp = timestamp
        self.data = data
        self.hash = hash
        self.node_id = node_id  # To track which node created this block


class Blockchain:
    def __init__(self, ledger_file):
        self.chain = []
        self.ledger_file = ledger_file
        if os.path.exists(self.ledger_file):
            self.load_ledger()
        else:
            self.create_genesis_block()

    def create_genesis_block(self):
        genesis_block = Block(0, "0", time.time(), "Genesis Block",
                              self.hash_block(0, "0", time.time(), "Genesis Block"), "System")
        self.chain.append(genesis_block)
        self.save_block_to_ledger(genesis_block)
        print(f"Genesis Block Created: Index=0, Hash={genesis_block.hash}")

    def hash_block(self, index, previous_hash, timestamp, data):
        block_string = f"{index}{previous_hash}{timestamp}{data}".encode()
        return hashlib.sha256(block_string).hexdigest()

    def create_block(self, data, node_id):
        last_block = self.chain[-1]
        index = last_block.index + 1
        timestamp = time.time()
        hash = self.hash_block(index, last_block.hash, timestamp, data)

        new_block = Block(index, last_block.hash, timestamp, data, hash, node_id)
        self.chain.append(new_block)
        self.save_block_to_ledger(new_block)
        print(f"Block Added: Index={index}, Node={node_id}, Data={data}, Hash={hash}")

    def save_block_to_ledger(self, block):
        with open(self.ledger_file, 'a') as ledger:
            ledger.write(f"{block.index},{block.previous_hash},{block.timestamp},{block.data},{block.hash},{block.node_id}\n")

    def load_ledger(self):
        with open(self.ledger_file, 'r') as ledger:
            for line in ledger.readlines():
                line_parts = line.strip().split(',')
                if len(line_parts) != 6:
                    print(f"Skipping malformed line in ledger: {line.strip()}")
                    continue
                index, previous_hash, timestamp, data, hash, node_id = line_parts
                block = Block(int(index), previous_hash, float(timestamp), data, hash, node_id)
                self.chain.append(block)
        print(f"Loaded {len(self.chain)} blocks from ledger.")

    def display_ledger(self):
        with open(self.ledger_file, 'r') as ledger:
            contents = ledger.read()
            print("Blockchain Ledger Contents:\n", contents)

    def evaluate_blockchain(self):
        print(f"\nBlockchain Evaluation:")
        print(f"Total Blocks: {len(self.chain)}")
        if len(self.chain) > 0:
            first_block = self.chain[0]
            last_block = self.chain[-1]
            print(f"First Block -> Index: {first_block.index}, Hash: {first_block.hash}")
            print(f"Last Block -> Index: {last_block.index}, Hash: {last_block.hash}")
        else:
            print("No blocks in the chain yet.")


class ProofOfShareBlockchain(Blockchain):
    def __init__(self, ledger_file, shares):
        super().__init__(ledger_file)
        self.shares = shares

    def proof_of_share(self, node_share, other_shares):
        if len(other_shares) >= 2:
            combined_shares = [node_share] + other_shares
            try:
                secret = reconstruct_secret(combined_shares)
                return secret == 123  # Assuming the secret is 123 for this example
            except:
                return False
        return False

    def add_block_with_proof(self, data, node_share, other_shares, node_id):
        if self.proof_of_share(node_share, other_shares):
            self.create_block(data, node_id)
            print(f"Block added by node {node_id} with share {node_share}")
        else:
            print(f"Block rejected for node {node_id} with share {node_share}")


# Ledger Validation
def validate_ledger(ledger_file):
    valid = True
    with open(ledger_file, 'r') as ledger:
        previous_hash = "0"
        invalid_blocks = []
        for line in ledger.readlines():
            line_parts = line.strip().split(',')
            if len(line_parts) != 6:
                print(f"Skipping malformed line in ledger: {line.strip()}")
                continue
            index, prev_hash, timestamp, data, hash, node_id = line_parts
            calculated_hash = hashlib.sha256(f"{index}{prev_hash}{timestamp}{data}".encode()).hexdigest()

            if calculated_hash != hash or prev_hash != previous_hash:
                print(f"Invalid Block at index {index}")
                invalid_blocks.append(index)
                valid = False
            previous_hash = hash

    if valid:
        print("Blockchain Ledger is Valid")
    else:
        print(f"Blockchain has {len(invalid_blocks)} invalid blocks: {invalid_blocks}")
    return valid


# Excel File Processing
def browse_file():
    Tk().withdraw()  # Close the root window
    file_path = askopenfilename(title="Select Excel File", filetypes=[("Excel files", "*.csv")])
    return file_path


def add_blocks_from_excel(blockchain, node_share, other_shares, node_id):
    file_path = browse_file()
    if not file_path:
        print("No file selected")
        return

    df = pd.read_csv(file_path)
    for _, row in df.iterrows():
        block_data = str(row.to_dict())
        blockchain.add_block_with_proof(block_data, node_share, other_shares, node_id)


# Homomorphic Encryption Functions (Paillier-based)
def encrypt_model_update(public_key, model_update):
    return public_key.encrypt(model_update)


def decrypt_model_update(private_key, encrypted_update):
    return private_key.decrypt(encrypted_update)


# Testing
if __name__ == "__main__":
    # Paillier keys for homomorphic encryption
    public_key, private_key = generate_paillier_keys()

    # For shared ledger
    ledger_file = "shared_ledger.txt"

    # Initialize the blockchain with shared ledger
    blockchain = ProofOfShareBlockchain(ledger_file, generate_shares(123, 5, 3))

    # Example node_id and shares
    node_id = 1
    node_share = (1, 123)  # Example share for the node
    other_shares = [(2, 234), (3, 345)]  # Example shares from other nodes

    # Homomorphic encryption of a model update (example)
    model_update = 100  # Sample model update
    encrypted_update = encrypt_model_update(public_key, model_update)
    decrypted_update = decrypt_model_update(private_key, encrypted_update)

    print(f"Original Model Update: {model_update}")
    print(f"Decrypted Model Update: {decrypted_update}")

    # Add blocks from Excel
    add_blocks_from_excel(blockchain, node_share, other_shares, node_id)

    # Display the ledger
    blockchain.display_ledger()

    # Evaluate the blockchain
    blockchain.evaluate_blockchain()

    # Validate the ledger
    validate_ledger(ledger_file)
