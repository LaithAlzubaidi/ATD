class ProofOfShareBlockchain(Blockchain):
    def __init__(self, ledger_file, shares):
        super().__init__(ledger_file)
        self.shares = shares

    def proof_of_share(self, node_share, other_shares):
        if len(other_shares) >= 2:
            combined_shares = [node_share] + other_shares
            try:
                secret = reconstruct_secret(combined_shares)
                return secret == 123  # Assuming the secret is 123 for this example
            except:
                return False
        return False

    def add_block_with_proof(self, data, node_share, other_shares):
        if self.proof_of_share(node_share, other_shares):
            self.create_block(data)
            print(f"Block added by node with share {node_share}")
        else:
            print(f"Block rejected for node with share {node_share}")

# Example usage with proof of share
blockchain = ProofOfShareBlockchain("blockchain_ledger.txt", shares)
node_share = shares[0]
other_shares = [shares[1], shares[2]]
blockchain.add_block_with_proof("Block data 3", node_share, other_shares)
